
  # Premium Wheat Flour Branding

  This is a code bundle for Premium Wheat Flour Branding. The original project is available at https://www.figma.com/design/dmwlJiZ7YY4E6hyuYTDyac/Premium-Wheat-Flour-Branding.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  